package cafe;

import java.util.*;

public class Cafe {
    private List<Employee> employees;
    private String name;
    private int capacity;

    public Cafe(String name, int capacity) {
        this.employees = new ArrayList<>();
        this.name = name;
        this.capacity = capacity;
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public boolean removeEmployee(String name) {
        for (Employee employee : employees) {
            if (employee.getName().equals(name)) {
                return employees.remove(employee);
            }
        }
        return false;
    }

    public Employee getOldestEmployee() {
        int maxAge = Integer.MIN_VALUE;
        for (Employee employee : employees) {
            if (employee.getAge() > maxAge) {
                maxAge = employee.getAge();
            }
        }
        for (Employee employee : employees) {
            if (employee.getAge() == maxAge) {
                return employee;
            }
        }
        return null;
    }

    public Employee getEmployee(String name) {
        if (!employees.isEmpty()) {
            for (Employee employee : employees) {
                if (employee.getName().equals(name)) {
                    return employee;
                }
            }
        }
        return null;
    }

    public int getCount() {
        return employees.size();
    }


    public String report() {
        StringBuilder builder = new StringBuilder();
        builder.append("Employees working at Cafe ").append(name).append(":").append(System.lineSeparator());
        for (Employee employee : employees) {
            builder.append("Employee: ").append(employee.getName()).append(", ")
                    .append(employee.getAge()).append(" from ").append(employee.getCountry()).append(System.lineSeparator());
        }
        return builder.toString().trim();
    }
}
