package com.JavaAdvanced.ExamPreparation.vetClinic;

import java.util.*;

public class Clinic {
    private List<Pet> pets;
    private int capacity;

    public Clinic(int capacity) {
        this.capacity = capacity;
        this.pets = new ArrayList<>();
    }

    public void add(Pet pet) {
        this.pets.add(pet);
    }

    public boolean remove(String name) {
        for (Pet pet : this.pets) {
            if (pet.getName().equals(name)) {
                return this.pets.remove(pet);
            }
        }
        return false;
    }

    public Pet getPet(String name, String owner) {
        if (this.pets.size() != 0) {
            for (Pet pet : this.pets) {
                if (pet.getName().equals(name) && pet.getOwner().equals(owner)) {
                    return pet;
                }
            }
        }
        return null;
    }

    public Pet getOldestPet() {
        if (this.pets.size() == 0) {
            return null;
        } else {
            return this.pets.stream().max(Comparator.comparingInt(Pet::getAge)).get();
        }
    }

    public int getCount(){
        return this.pets.size();
    }

   public String getStatistics(){
        StringBuilder printBuilder = new StringBuilder();
        printBuilder.append("The clinic has the following patients:").append(System.lineSeparator());
       for (Pet pet : pets) {
           printBuilder.append(pet.getName().toString()).append(" ").append(pet.getOwner().toString()).append(System.lineSeparator());
       }


       return printBuilder.toString();
   }
}
